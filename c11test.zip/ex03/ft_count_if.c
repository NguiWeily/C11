/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_if.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 15:05:11 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 15:05:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

// Function to count the number of elements in the array that satisfy the condition
int ft_count_if(char **tab, int length, int (*f)(char*))
{
    int i;
    int count;

    count = 0;
    i = 0;
    while (i < length) // Iterate through each element of the array
    {
        if ((*f)(tab[i])) // Call the function f on the current element and check if it satisfies the condition
            count++; // Increment the count if the condition is true
        i++; // Move to the next element
    }
    return count; // Return the final count
}

// Function to check if a string starts with an uppercase letter
int is_uppercase(char *str)
{
    return (*str >= 'A' && *str <= 'Z'); // Returns 1 if the first character is uppercase, 0 otherwise
}

int main(void)
{
    char *words[] = {"Hello", "world", "Osaka", "Germany"};

    // Call the ft_count_if function with the array of words, its length, and the is_uppercase function
    int count = ft_count_if(words, sizeof(words) / sizeof(words[0]), is_uppercase);
    printf("Number of uppercase words: %d\n", count); // Print the number of uppercase words

    return 0;
}

