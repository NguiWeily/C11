/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 16:14:22 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 16:14:25 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putchar(char c)
{
	write(1, &c, 1); // Writes a single character 'c' to the standard output
}

void ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		ft_putchar('-'); // Writes a '-' character to indicate a negative number
		ft_putchar('2'); // Writes '2' as the first digit of the number
		ft_putnbr(147483648); // Recursively calls ft_putnbr with the remaining digits
	}
	else if (nb < 0)
	{
		ft_putchar('-'); // Writes a '-' character to indicate a negative number
		nb = -nb; // Converts nb to a positive number
		ft_putnbr(nb); // Recursively calls ft_putnbr with the positive number
	}
	else if (nb > 9)
	{
		ft_putnbr(nb / 10); // Recursively calls ft_putnbr with the quotient
		ft_putnbr(nb % 10); // Recursively calls ft_putnbr with the remainder
	}
	else
		ft_putchar(nb + 48); // Writes the single digit number as a character
}

