/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_any.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 15:04:49 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 15:04:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*The `ft_any` function is a utility function that checks if any element in an array satisfies a specific condition. It returns 1 if at least one element meets the condition, and 0 otherwise.

Here's the function prototype:

```c
int ft_any(char **tab, int (*f)(char *));
```

Let's break down the function and its parameters:

- `tab`: It represents an array of strings (an array of pointers to characters) that we want to check.
- `f`: It is a function pointer that points to a function accepting a string (a pointer to characters) as an argument and returning an integer. This function `f` defines the condition that needs to be satisfied for an element to be considered as "meeting the condition."

The `ft_any` function iterates over each element in the array `tab` and applies the provided function `f` to each element. If the condition defined by `f` is met for any element in the array, the function immediately returns 1, indicating that at least one element satisfies the condition. If none of the elements meet the condition, the function returns 0.

Here's an example usage of `ft_any`:

```c
#include <stdio.h>

int is_vowel(char *str)
{
    char vowels[] = "aeiou";

    for (int i = 0; str[i] != '\0'; i++) {
        for (int j = 0; vowels[j] != '\0'; j++) {
            if (str[i] == vowels[j]) {
                return 1; // Found a vowel, return 1
            }
        }
    }

    return 0; // No vowels found, return 0
}

int main(void)
{
    char *words[] = {"apple", "banana", "cat", "dog", "elephant"};

    int result = ft_any(words, &is_vowel);

    if (result) {
        printf("At least one word contains a vowel.\n");
    } else {
        printf("No words contain a vowel.\n");
    }

    return 0;
}
```

In this example, the `ft_any` function is used to check if any of the words in the `words` array contain a vowel. The `is_vowel` function is provided as the condition to be checked for each element. It checks if a given string contains any of the vowels. The `ft_any` function iterates over the words, applies the `is_vowel` function to each word, and returns 1 if any word contains a vowel. In this case, the output will be "At least one word contains a vowel."

The `ft_any` function provides a convenient way to check if any element in an array meets a specific condition. It allows you to perform custom checks or conditions on the elements of an array and determine if the condition is satisfied by any element.*/
#include <stdio.h>

int ft_is_vowel(char *str)
{
    if (str[0] == 'a' || str[0] == 'e' || str[0] == 'i' || str[0] == 'o' || str[0] == 'u')
        return 1; // Return 1 if the first character is a vowel
    else
        return 0; // Return 0 otherwise
}

int		ft_any(char **tab, int (*f)(char*))
{
	int		i;

	i = -1;
	while (tab[++i] != 0)
		if ((*f)(tab[i]) != 0)
			return (1);
	return (0);
}

int main(void)
{
    char *tab[] = {"hello", "world", "apple", "orange", NULL}; // Array of strings

    int result = ft_any(tab, &ft_is_vowel); // Call ft_any to check if any string starts with a vowel

    if (result)
        printf("At least one string starts with a vowel.\n");
    else
        printf("No string starts with a vowel.\n");

    return 0;
}

