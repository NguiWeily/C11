/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_foreach.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 15:03:36 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 15:03:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*The ft_foreach function is a generic function that applies a given function to each element in an array. It provides a convenient way to perform a specific action or operation on every element of an array without explicitly writing a loop.

Here's the function prototype:

c
Copy code
void ft_foreach(int *tab, int length, void (*f)(int));
Let's break down the function and its parameters:

tab: It represents the array of integers on which the function f will be applied.
length: It specifies the length or size of the array tab.
f: It is a function pointer that points to a function accepting an integer argument and returning void. This function f will be applied to each element of the array.
The purpose of ft_foreach is to iterate over each element of the array tab, calling the provided function f for each element. The function f can perform any desired operation or action on the elements.

Here's an example usage of ft_foreach:

#include <stdio.h>

void print_square(int num)
{
    int square = num * num;
    printf("%d ", square);
}

int main(void)
{
    int tab[] = {1, 2, 3, 4, 5};
    int length = sizeof(tab) / sizeof(tab[0]);

    ft_foreach(tab, length, &print_square);

    return 0;
}
In this example, the ft_foreach function is used to apply the print_square function to each element in the tab array. The print_square function calculates the square of a number and prints it. So, the output will be: 1 4 9 16 25.

By using ft_foreach, you can easily perform operations on each element of an array without writing repetitive loops, enhancing code readability and reusability.*/

#include <unistd.h>
/*
// Function to print an integer
void ft_putnbr(int num)
{
    char digit;

    if (num < 0)
    {
        write(1, "-", 1); // Write a '-' character for negative numbers
        num *= -1; // Convert the number to positive for further processing
    }

    if (num > 9)
        ft_putnbr(num / 10); // Recursively call ft_putnbr to print the digits before the last one

    digit = num % 10 + '0'; // Extract the last digit and convert it to a character
    write(1, &digit, 1); // Write the digit character to the standard output
}*/

// Function to apply a given function on each element of an integer array
void ft_foreach(int *tab, int length, void (*f)(int))
{
    int i; // Variable to keep track of the index

    i = 0; // Initialize the index to 0
    while (i < length) // Loop while the index is less than the length of the array
    {
        f(tab[i]); // Call the provided function 'f' on the current element of the array
        i++; // Increment the index to move to the next element
    }
}
/*
int main(void)
{
    int tab[] = {1, 2, 3, 4, 5}; // Array of integers
    int length = sizeof(tab) / sizeof(tab[0]); // Calculate the length of the array

    ft_foreach(tab, length, &ft_putnbr); // Call ft_foreach to apply ft_putnbr on each element of the array
    return 0; // Return 0 to indicate successful program execution
}*/
#include <stdio.h>

void print_square(int num)
{
    int square = num * num;
    printf("%d ", square);
}

int main(void)
{
    int tab[] = {1, 2, 3, 4, 5};
    int length = sizeof(tab) / sizeof(tab[0]);

    ft_foreach(tab, length, &print_square);

    return 0;
}
