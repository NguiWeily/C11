/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 15:05:33 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 15:05:36 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

// Function to check if the array is sorted according to the given comparison function
int ft_is_sort(int *tab, int length, int (*f)(int, int))
{
    int i;
    int sorted;

    i = 0;
    sorted = 1;
    while (i < length - 1 && sorted) // Iterate through the array until the second-to-last element or until sorted becomes 0
    {
        if ((*f)(tab[i], tab[i + 1]) < 0) // Compare adjacent elements using the comparison function f
            sorted = 0; // If the first element is lower than the second, set sorted to 0
        i++;
    }
    if (sorted != 1) // If sorted is not equal to 1, it means the array is unsorted
    {
        sorted = 1;
        i = 0;
        while (i < length - 1) // Iterate through the array again
        {
            if ((*f)(tab[i], tab[i + 1]) > 0) // If any pair of adjacent elements returns a positive value, return 0 (array is unsorted)
                return 0;
            i++;
        }
    }
    return 1; // Return 1 if the array is sorted
}

// Function to compare two integers (used as the comparison function)
int compare(int a, int b)
{
    return a - b; // Returns a negative value if a is lower than b, 0 if they are equal, or a positive value otherwise
}

int main(void)
{
    int arr1[] = {1, 2, 3, 4, 5};
    int arr2[] = {5, 4, 3, 2, 1};
    int arr3[] = {1, 3, 2, 4, 5};

    // Call ft_is_sort function with the arrays, their length, and the comparison function
    int sorted1 = ft_is_sort(arr1, sizeof(arr1) / sizeof(arr1[0]), compare);
    int sorted2 = ft_is_sort(arr2, sizeof(arr2) / sizeof(arr2[0]), compare);
    int sorted3 = ft_is_sort(arr3, sizeof(arr3) / sizeof(arr3[0]), compare);

    // Print the sorting status of each array
    printf("Array 1 is%s sorted.\n", sorted1 ? "" : " not");
    printf("Array 2 is%s sorted.\n", sorted2 ? "" : " not");
    printf("Array 3 is%s sorted.\n", sorted3 ? "" : " not");

    return 0;
}

