/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_string_tab.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 15:06:16 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 15:06:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

// Swaps the pointers of two strings
void ft_swap(char **a, char **b)
{
    char *tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}

// Compares two strings character by character
int ft_strcmp(char *s1, char *s2)
{
    unsigned int i = 0;
    while (s1[i] == s2[i] && s1[i] != '\0' && s2[i] != '\0')
    {
        i++;
    }
    return (s1[i] - s2[i]);
}

// Sorts the string array by exchanging the array's pointers
void ft_sort_string_tab(char **tab)
{
    int index;
    int i = 0;
    while (tab[i])
    {
        index = 0;
        while (tab[index])
        {
            if (tab[index + 1] && ft_strcmp(tab[index], tab[index + 1]) > 0)
                ft_swap(&tab[index], &tab[index + 1]);
            index++;
        }
        i++;
    }
}

// Prints the elements of the string array
void ft_print_string_tab(char **tab)
{
    while (*tab != NULL)
    {
        printf("%s\n", *tab);
        tab++;
    }
}

int main(void)
{
    char *tab[] = {"Osaka", "Germany", "Hello", "world", NULL};

    printf("Before sorting:\n");
    ft_print_string_tab(tab);

    ft_sort_string_tab(tab);

    printf("\nAfter sorting:\n");
    ft_print_string_tab(tab);

    return 0;
}

