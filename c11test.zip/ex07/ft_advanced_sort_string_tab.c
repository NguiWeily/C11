/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_advanced_sort_string_tab.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 16:15:47 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 16:15:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

// Swaps the values of two pointers to strings
void	ft_swap(char **a, char **b)
{
	char	*tmp;
	
	tmp = *a;
	*a = *b;
	*b = tmp;
}

// Performs advanced sorting of string array using a comparison function
void	ft_advanced_sort_string_tab(char **tab, int (*cmp)(char *, char *))
{
	int	index;
	int	i;

	i = 0;
	while (tab[i])
	{
		index = 0;
		while (tab[index])
		{
			// Compares adjacent strings using the provided comparison function and swaps them if necessary
			if (tab[index + 1] && (*cmp)(tab[index], tab[index + 1]) > 0)
				ft_swap(&tab[index], &tab[index + 1]);
			index++;
		}
		i++;
	}
}

// Custom string comparison function
int ft_strcmp(char *s1, char *s2)
{
	unsigned int i = 0;
	while (s1[i] == s2[i] && s1[i] != '\0' && s2[i] != '\0')
	{
		i++;
	}
	return (s1[i] - s2[i]);
}

// Prints each string in the string array
void ft_print_string_tab(char **tab)
{
	while (*tab != NULL)
	{
		printf("%s\n", *tab);
		tab++;
	}
}

int main(void)
{
	char *tab[] = {"Osaka", "Germany", "Hello", "world", NULL};

	printf("Before sorting:\n");
	ft_print_string_tab(tab);

	ft_advanced_sort_string_tab(tab, &ft_strcmp);

	printf("\nAfter sorting:\n");
	ft_print_string_tab(tab);

	return 0;
}

