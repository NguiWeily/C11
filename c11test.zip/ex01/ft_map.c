/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/04 15:04:18 by wngui             #+#    #+#             */
/*   Updated: 2023/07/04 15:04:24 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*The `ft_map` function is a generic function that applies a given function to each element in an array and stores the results in a new array. It allows you to transform each element of an array based on a specific operation defined by the provided function.

Here's the function prototype:

int *ft_map(int *tab, int length, int (*f)(int));

Let's break down the function and its parameters:

- `tab`: It represents the array of integers on which the function `f` will be applied.
- `length`: It specifies the length or size of the array `tab`.
- `f`: It is a function pointer that points to a function accepting an integer argument and returning an integer. This function `f` defines the operation to be performed on each element of the array.

The purpose of `ft_map` is to iterate over each element of the array `tab`, apply the provided function `f` to each element, and store the results in a new array. The new array, containing the transformed elements, is then returned by the `ft_map` function.

Here's an example usage of `ft_map`:

#include <stdio.h>
#include <stdlib.h>

int square(int num)
{
    return num * num;
}

int main(void)
{
    int tab[] = {1, 2, 3, 4, 5};
    int length = sizeof(tab) / sizeof(tab[0]);

    int *result = ft_map(tab, length, &square);

    for (int i = 0; i < length; i++) {
        printf("%d ", result[i]);
    }

    free(result);

    return 0;
}

In this example, the `ft_map` function is used to apply the `square` function to each element in the `tab` array. The `square` function calculates the square of a number. The transformed elements are stored in a new dynamically allocated array, and then each element is printed. The output will be: `1 4 9 16 25`.

The `ft_map` function allows you to apply a specific operation or transformation to each element of an array and obtain a new array with the transformed elements. It provides a flexible way to process arrays and perform element-wise computations.*/
#include <stdlib.h>
#include <stdio.h>

int ft_multiply_by_two(int num)
{
    return num * 2;
}

int *ft_map(int *tab, int length, int (*f)(int))
{
	int i;       // Variable to keep track of the index
	int *res;    // Pointer to store the resulting array
	int *d;      // Temporary pointer for allocation check

	res = malloc(length * sizeof(int)); // Allocate memory for the resulting array

	d = res; // Assign the temporary pointer to the resulting array

	if (!d) // Check if memory allocation failed
		return (0); // Return NULL if allocation failed

	i = 0; // Initialize the index to 0

	while (i < length) // Loop while the index is less than the length of the array
	{
		res[i] = (*f)(tab[i]); // Apply the provided function to the current element and store the result in the resulting array
		i++; // Increment the index to move to the next element
	}

	return (res); // Return the resulting array
}

int main(void)
{
    int tab[] = {1, 2, 3, 4, 5}; // Array of integers
    int length = sizeof(tab) / sizeof(tab[0]); // Calculate the length of the array

    int *result = ft_map(tab, length, &ft_multiply_by_two); // Call ft_map to apply ft_multiply_by_two on each element

    // Print the resulting array
    int i = 0;
    while (i < length)
    {
        printf("%d ", result[i]);
        i++;
    }
    printf("\n");

    free(result); // Free the dynamically allocated memory

    return 0;
}
